package com.hardik.RestaurantBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
