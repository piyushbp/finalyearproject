export class Fooditem {
  id: number;
  name: string;
  price: number;
  category: string;
  available: string;
  description: string;
  createDate: string;
  updateDate: string;
}
