import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-items-details',
  templateUrl: './food-items-details.component.html',
  styleUrls: ['./food-items-details.component.css']
})
export class FoodItemsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
