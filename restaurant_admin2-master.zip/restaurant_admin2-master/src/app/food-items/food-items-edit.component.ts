import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-items-edit',
  templateUrl: './food-items-edit.component.html',
  styleUrls: ['./food-items-edit.component.css']
})
export class FoodItemsEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
